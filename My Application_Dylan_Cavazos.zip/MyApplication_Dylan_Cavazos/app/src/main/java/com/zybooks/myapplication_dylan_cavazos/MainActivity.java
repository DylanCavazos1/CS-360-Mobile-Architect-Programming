package com.zybooks.myapplication_dylan_cavazos;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText nameText;
    private TextView textGreeting;
    private Button buttonSayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the views
        nameText = findViewById(R.id.nameText);
        textGreeting = findViewById(R.id.textGreeting);
        buttonSayHello = findViewById(R.id.buttonSayHello);

        // Set the buttonSayHello enabled attribute to false
        buttonSayHello.setEnabled(false);

        // Add a text changed listener to the nameText field with following logic
        nameText.addTextChangedListener(new TextWatcher() {
            // Called before the text is edited
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            // called when the text is edited
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Enable button if there is text, disable if empty
                buttonSayHello.setEnabled(s.length() > 0);
            }
            // called after the text is edited
            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    // Function to display greeting
    public void SayHello(View view) {
        String name = nameText.getText().toString();
        if (!name.isEmpty()) {
            textGreeting.setText("Hello, " + name + "!");
        } else {
            textGreeting.setText(""); // Clear the greeting if no name is entered
        }
    }
}

